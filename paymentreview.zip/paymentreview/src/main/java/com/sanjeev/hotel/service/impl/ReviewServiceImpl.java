package com.sanjeev.hotel.service.impl;



import com.sanjeev.hotel.dto.ReviewDTO;
import com.sanjeev.hotel.entity.Review;
import com.sanjeev.hotel.exception.ResourceNotFoundException;
import com.sanjeev.hotel.repository.ReviewRepository;
import com.sanjeev.hotel.service.ReviewService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ReviewServiceImpl implements ReviewService {

    private final ReviewRepository reviewRepository;

    @Override
    public Review createReview(ReviewDTO dto) {
        Review r = Review.builder()
                .reservationId(dto.getReservationId())
                .rating(dto.getRating())
                .comment(dto.getComment())
                .reviewDate(dto.getReviewDate() == null ? LocalDate.now() : dto.getReviewDate())
                .build();
        return reviewRepository.save(r);
    }

    @Override
    public Review updateReview(Long id, ReviewDTO dto) {
        Review existing = reviewRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Review not found with id: " + id));
        existing.setRating(dto.getRating());
        existing.setComment(dto.getComment());
        existing.setReviewDate(dto.getReviewDate() == null ? existing.getReviewDate() : dto.getReviewDate());
        existing.setReservationId(dto.getReservationId());
        return reviewRepository.save(existing);
    }

    @Override
    public void deleteReview(Long id) {
        Review existing = reviewRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Review not found with id: " + id));
        reviewRepository.delete(existing);
    }

    @Override
    public Review getReviewById(Long id) {
        return reviewRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Review not found with id: " + id));
    }

    @Override
    public List<Review> getAllReviews() {
        return reviewRepository.findAll();
    }

    @Override
    public List<Review> getReviewsByRating(int rating) {
        return reviewRepository.findByRating(rating);
    }

    @Override
    public List<Review> getRecentReviews(int limit) {
        return reviewRepository.findAllByOrderByReviewDateDesc(PageRequest.of(0, limit));
    }
}
