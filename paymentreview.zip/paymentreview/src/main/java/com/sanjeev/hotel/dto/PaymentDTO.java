package com.sanjeev.hotel.dto;


import lombok.Data;

import java.time.LocalDate;

@Data
public class PaymentDTO {
    private Long reservationId;
    private Double amount;
    private LocalDate paymentDate;
    private String paymentStatus;
}
