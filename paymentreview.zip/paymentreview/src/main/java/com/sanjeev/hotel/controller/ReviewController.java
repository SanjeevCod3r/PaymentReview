package com.sanjeev.hotel.controller;


import com.sanjeev.hotel.dto.ReviewDTO;
import com.sanjeev.hotel.entity.Review;
import com.sanjeev.hotel.response.ApiResponse;
import com.sanjeev.hotel.service.ReviewService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class ReviewController {

    private final ReviewService reviewService;

    @PostMapping("/review/post")
    public ResponseEntity<ApiResponse<Review>> createReview(@RequestBody ReviewDTO dto) {
        Review r = reviewService.createReview(dto);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("POSTSUCCESS", "Review added successfully", r));
    }

    @GetMapping("/review/all")
    public ResponseEntity<?> getAllReviews() {
        List<Review> list = reviewService.getAllReviews();
        if (list.isEmpty()) {
            return ResponseEntity.ok(ApiResponse.simple("GETALLFAILS", "Review list is empty"));
        }
        return ResponseEntity.ok(ApiResponse.success("GETSUCCESS", "Fetched reviews", list));
    }

    @GetMapping("/review/{reviewId}")
    public ResponseEntity<ApiResponse<Review>> getReviewById(@PathVariable Long reviewId) {
        Review r = reviewService.getReviewById(reviewId);
        return ResponseEntity.ok(ApiResponse.success("GETSUCCESS", "Fetched review", r));
    }

    @GetMapping("/reviews/rating/{rating}")
    public ResponseEntity<?> getReviewsByRating(@PathVariable int rating) {
        List<Review> list = reviewService.getReviewsByRating(rating);
        if (list.isEmpty()) {
            return ResponseEntity.ok(ApiResponse.simple("GETALLFAILS", "No reviews found with rating: " + rating));
        }
        return ResponseEntity.ok(ApiResponse.success("GETSUCCESS", "Fetched reviews by rating", list));
    }

    @GetMapping("/reviews/recent")
    public ResponseEntity<?> getRecentReviews(@RequestParam(value = "limit", required = false, defaultValue = "10") int limit) {
        List<Review> recent = reviewService.getRecentReviews(limit);
        if (recent.isEmpty()) {
            return ResponseEntity.ok(ApiResponse.simple("GETALLFAILS", "No recent reviews found"));
        }
        return ResponseEntity.ok(ApiResponse.success("GETSUCCESS", "Fetched recent reviews", recent));
    }

    @PutMapping("/review/update/{reviewId}")
    public ResponseEntity<ApiResponse<Review>> updateReview(@PathVariable Long reviewId, @RequestBody ReviewDTO dto) {
        Review updated = reviewService.updateReview(reviewId, dto);
        return ResponseEntity.ok(ApiResponse.success("UPDATESUCCESS", "Review updated successfully", updated));
    }

    @DeleteMapping("/review/delete/{reviewId}")
    public ResponseEntity<ApiResponse<?>> deleteReview(@PathVariable Long reviewId) {
        reviewService.deleteReview(reviewId);
        return ResponseEntity.ok(ApiResponse.simple("DELETESUCCESS", "Review deleted successfully"));
    }
}

