package com.sanjeev.hotel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaymentreviewApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaymentreviewApplication.class, args);
	}

}
