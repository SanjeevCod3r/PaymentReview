package com.sanjeev.hotel.controller;

import com.sanjeev.hotel.dto.PaymentDTO;
import com.sanjeev.hotel.entity.Payment;
import com.sanjeev.hotel.service.PaymentService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/payments")
@RequiredArgsConstructor
public class PaymentWebController {

    private final PaymentService paymentService;

    @GetMapping
    public String viewAllPayments(Model model) {
        List<Payment> payments = paymentService.getAllPayments();
        model.addAttribute("payments", payments);
        model.addAttribute("totalRevenue", paymentService.getTotalRevenue());
        return "payments/list";
    }

    @GetMapping("/add")
    public String showAddPaymentForm(Model model) {
        model.addAttribute("payment", new PaymentDTO());
        return "payments/add";
    }

    @PostMapping("/add")
    public String addPayment(@ModelAttribute("payment") PaymentDTO dto) {
        paymentService.createPayment(dto);
        return "redirect:/payments";
    }

    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable("id") Long id, Model model) {
        Payment payment = paymentService.getPaymentById(id);
        PaymentDTO dto = new PaymentDTO(payment.getReservationId(), payment.getAmount(),
                payment.getPaymentDate(), payment.getPaymentStatus());
        model.addAttribute("payment", dto);
        model.addAttribute("paymentId", id);
        return "payments/edit";
    }

    @PostMapping("/update/{id}")
    public String updatePayment(@PathVariable("id") Long id, @ModelAttribute("payment") PaymentDTO dto) {
        paymentService.updatePayment(id, dto);
        return "redirect:/payments";
    }

    @GetMapping("/delete/{id}")
    public String deletePayment(@PathVariable("id") Long id) {
        paymentService.deletePayment(id);
        return "redirect:/payments";
    }
}
