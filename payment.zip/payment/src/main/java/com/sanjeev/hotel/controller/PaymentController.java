package com.sanjeev.hotel.controller;


import com.sanjeev.hotel.dto.PaymentDTO;
import com.sanjeev.hotel.entity.Payment;
import com.sanjeev.hotel.response.ApiResponse;
import com.sanjeev.hotel.service.PaymentService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class PaymentController {

    private final PaymentService paymentService;

    @PostMapping("/payment/post")
    public ResponseEntity<ApiResponse<Payment>> createPayment(@RequestBody PaymentDTO dto) {
        Payment p = paymentService.createPayment(dto);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("POSTSUCCESS", "Payment added successfully", p));
    }

    @GetMapping("/payment/all")
    public ResponseEntity<?> getAllPayments() {
        List<Payment> list = paymentService.getAllPayments();
        if (list.isEmpty()) {
            return ResponseEntity.ok(ApiResponse.simple("GETALLFAILS", "Payment list is empty"));
        }
        return ResponseEntity.ok(ApiResponse.success("GETSUCCESS", "Fetched payments", list));
    }

    @GetMapping("/payment/{paymentId}")
    public ResponseEntity<ApiResponse<Payment>> getPaymentById(@PathVariable Long paymentId) {
        Payment p = paymentService.getPaymentById(paymentId);
        return ResponseEntity.ok(ApiResponse.success("GETSUCCESS", "Fetched payment", p));
    }

    @GetMapping("/payments/status/{status}")
    public ResponseEntity<?> getPaymentsByStatus(@PathVariable String status) {
        List<Payment> list = paymentService.getPaymentsByStatus(status);
        if (list.isEmpty()) {
            return ResponseEntity.ok(ApiResponse.simple("GETALLFAILS", "No payments found with status: " + status));
        }
        return ResponseEntity.ok(ApiResponse.success("GETSUCCESS", "Fetched payments by status", list));
    }

    @GetMapping("/payments/total-revenue")
    public ResponseEntity<ApiResponse<Double>> getTotalRevenue() {
        Double total = paymentService.getTotalRevenue();
        return ResponseEntity.ok(ApiResponse.success("GETSUCCESS", "Total revenue fetched", total));
    }

    @PutMapping("/payment/{paymentId}")
    public ResponseEntity<ApiResponse<Payment>> updatePayment(@PathVariable Long paymentId, @RequestBody PaymentDTO dto) {
        Payment updated = paymentService.updatePayment(paymentId, dto);
        return ResponseEntity.ok(ApiResponse.success("UPDATESUCCESS", "Payment updated successfully", updated));
    }

    @DeleteMapping("/payment/{paymentId}")
    public ResponseEntity<ApiResponse<?>> deletePayment(@PathVariable Long paymentId) {
        paymentService.deletePayment(paymentId);
        return ResponseEntity.ok(ApiResponse.simple("DELETESUCCESS", "Payment deleted successfully"));
    }
}
