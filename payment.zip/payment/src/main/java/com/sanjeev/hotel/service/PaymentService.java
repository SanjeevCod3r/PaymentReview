package com.sanjeev.hotel.service;


import com.sanjeev.hotel.dto.PaymentDTO;
import com.sanjeev.hotel.entity.Payment;

import java.util.List;

public interface PaymentService {
    Payment createPayment(PaymentDTO dto);
    Payment updatePayment(Long id, PaymentDTO dto);
    void deletePayment(Long id);
    Payment getPaymentById(Long id);
    List<Payment> getAllPayments();
    List<Payment> getPaymentsByStatus(String status);
    Double getTotalRevenue();
}
