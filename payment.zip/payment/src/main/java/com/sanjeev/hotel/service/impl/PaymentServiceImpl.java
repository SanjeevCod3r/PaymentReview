package com.sanjeev.hotel.service.impl;


import com.sanjeev.hotel.dto.PaymentDTO;
import com.sanjeev.hotel.entity.Payment;
import com.sanjeev.hotel.exception.ResourceNotFoundException;
import com.sanjeev.hotel.repository.PaymentRepository;
import com.sanjeev.hotel.service.PaymentService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.time.LocalDate;

@Service
@RequiredArgsConstructor
public class PaymentServiceImpl implements PaymentService {

    private final PaymentRepository paymentRepository;

    @Override
    public Payment createPayment(PaymentDTO dto) {
        Payment p = Payment.builder()
                .reservationId(dto.getReservationId())
                .amount(dto.getAmount())
                .paymentDate(dto.getPaymentDate() == null ? LocalDate.now() : dto.getPaymentDate())
                .paymentStatus(dto.getPaymentStatus())
                .build();
        return paymentRepository.save(p);
    }

    @Override
    public Payment updatePayment(Long id, PaymentDTO dto) {
        Payment existing = paymentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Payment not found with id: " + id));
        existing.setReservationId(dto.getReservationId());
        existing.setAmount(dto.getAmount());
        existing.setPaymentDate(dto.getPaymentDate() == null ? existing.getPaymentDate() : dto.getPaymentDate());
        existing.setPaymentStatus(dto.getPaymentStatus());
        return paymentRepository.save(existing);
    }

    @Override
    public void deletePayment(Long id) {
        Payment existing = paymentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Payment not found with id: " + id));
        paymentRepository.delete(existing);
    }

    @Override
    public Payment getPaymentById(Long id) {
        return paymentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Payment not found with id: " + id));
    }

    @Override
    public List<Payment> getAllPayments() {
        return paymentRepository.findAll();
    }

    @Override
    public List<Payment> getPaymentsByStatus(String status) {
        return paymentRepository.findByPaymentStatusIgnoreCase(status);
    }

    @Override
    public Double getTotalRevenue() {
        return paymentRepository.getTotalRevenue();
    }
}

