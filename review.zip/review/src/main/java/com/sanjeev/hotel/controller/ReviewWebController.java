package com.sanjeev.hotel.controller;

import com.sanjeev.hotel.dto.ReviewDTO;
import com.sanjeev.hotel.entity.Review;
import com.sanjeev.hotel.service.ReviewService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequiredArgsConstructor
@RequestMapping("/review")
public class ReviewWebController {

    private final ReviewService reviewService;

    // List all reviews
    @GetMapping("/list")
    public String listReviews(Model model) {
        model.addAttribute("reviews", reviewService.getAllReviews());
        return "review/review-list";
    }

    // Show add form
    @GetMapping("/new")
    public String newReview(Model model) {
        model.addAttribute("review", new ReviewDTO());
        return "review/review-form";
    }

    // Save new review
    @PostMapping("/save")
    public String saveReview(@ModelAttribute ReviewDTO dto) {
        reviewService.createReview(dto);
        return "redirect:/review/list";
    }

    // Show edit form
    @GetMapping("/edit/{id}")
    public String editReview(@PathVariable Long id, Model model) {
        Review review = reviewService.getReviewById(id);
        ReviewDTO dto = new ReviewDTO();
        dto.setReviewId(review.getReviewId());
        dto.setReservationId(review.getReservationId());
        dto.setRating(review.getRating());
        dto.setComment(review.getComment());
        dto.setReviewDate(review.getReviewDate());
        model.addAttribute("review", dto);
        return "review/review-form";
    }

    // Update review
    @PostMapping("/update/{id}")
    public String updateReview(@PathVariable Long id, @ModelAttribute ReviewDTO dto) {
        reviewService.updateReview(id, dto);
        return "redirect:/review/list";
    }

    // Delete review
    @GetMapping("/delete/{id}")
    public String deleteReview(@PathVariable Long id) {
        reviewService.deleteReview(id);
        return "redirect:/review/list";
    }
}
