package com.sanjeev.hotel.repository;


import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.sanjeev.hotel.entity.Review;

import java.util.List;

public interface ReviewRepository extends JpaRepository<Review, Long> {
    List<Review> findByRating(Integer rating);
    List<Review> findAllByOrderByReviewDateDesc(Pageable pageable);
}
