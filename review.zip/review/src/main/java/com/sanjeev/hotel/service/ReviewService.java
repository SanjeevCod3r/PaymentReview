package com.sanjeev.hotel.service;


import com.sanjeev.hotel.dto.ReviewDTO;
import com.sanjeev.hotel.entity.Review;

import java.util.List;

public interface ReviewService {
    Review createReview(ReviewDTO dto);
    Review updateReview(Long id, ReviewDTO dto);
    void deleteReview(Long id);
    Review getReviewById(Long id);
    List<Review> getAllReviews();
    List<Review> getReviewsByRating(int rating);
    List<Review> getRecentReviews(int limit);
}
