package com.sanjeev.hotel.dto;

import lombok.Data;

import java.time.LocalDate;

@Data
public class ReviewDTO {
	private Long reviewId; 
    private Long reservationId;
    private Integer rating;
    private String comment;
    private LocalDate reviewDate;
}
